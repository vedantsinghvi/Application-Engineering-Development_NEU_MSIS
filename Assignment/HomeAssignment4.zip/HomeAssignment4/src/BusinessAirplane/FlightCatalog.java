/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BusinessAirplane;

import java.util.ArrayList;
import java.util.Date;

/**
 *

 */
public class FlightCatalog {
    private ArrayList<Flight> flightCatalog;
    
public FlightCatalog()
{
    flightCatalog = new ArrayList<Flight>();
}

    public ArrayList<Flight> getFlightCatalog() {
        return flightCatalog;
    }

    public void setFlightCatalog(ArrayList<Flight> flightCatalog) {
        this.flightCatalog = flightCatalog;
    }
   
 public Flight addAirplane()
{
Flight a =new Flight();
flightCatalog.add(a);
return a;

}
public void deleteAirplane (Flight a)
{
    flightCatalog.remove(a);
}

public ArrayList<Flight> searchBySnD(String source, String dest){
    ArrayList<Flight> flights = new ArrayList<>();
    for(Flight flight : flightCatalog){
        if(flight.getSource().equalsIgnoreCase(source)&&flight.getDestination().equalsIgnoreCase(dest)){
            flights.add(flight);
        }
    }
    return flights;
}

public ArrayList<Flight> bestBuy(String source, String dest, Date date){
    ArrayList<Flight> flights = new ArrayList<>();
    double max = 999999999;
    Flight best = new Flight();
    for(Flight flight : flightCatalog){
        if(flight.getSource().equalsIgnoreCase(source)&&flight.getDestination().equalsIgnoreCase(dest)&&flight.getDate()==date){
            if(flight.getPrice()<= max){
                max = flight.getPrice();
                best = flight;
            }
            
        }
    }
    flights.add(best);
    return flights;
}
}
