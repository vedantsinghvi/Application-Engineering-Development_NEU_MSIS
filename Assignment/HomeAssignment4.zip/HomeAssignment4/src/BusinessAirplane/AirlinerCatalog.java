/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BusinessAirplane;

import java.util.ArrayList;

/**
 *
 * 
 */
public class AirlinerCatalog {
    private ArrayList<Airliner> airlinerCatalog;

 public AirlinerCatalog()
 {
     airlinerCatalog = new ArrayList<Airliner>();
 }
    public ArrayList<Airliner> getAirlinerCatalog() {
        return airlinerCatalog;
    }

    public void setAirlinerCatalog(ArrayList<Airliner> airlinerCatalog) {
        this.airlinerCatalog = airlinerCatalog;
    }
  
 public Airliner addAirliner()
 {
     Airliner ar=new Airliner();
airlinerCatalog.add(ar);
return ar;
 }

 public void  removeAirliner(Airliner ar)
 {
     airlinerCatalog.remove(ar);
 }
}