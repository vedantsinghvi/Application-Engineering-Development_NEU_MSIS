/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BusinessAirplane;

import com.sun.xml.internal.bind.v2.runtime.RuntimeUtil;
import java.util.ArrayList;

/**
 *
 * 
 */ 
public class Airliner {
    
        private String airlinerName;
        private int airlinerID;
        private int airlinerCustomerService;
        private FlightCatalog airlinerFlightCatalog;
        
        Airliner(){
            this.airlinerFlightCatalog = new FlightCatalog();
        }

    public FlightCatalog getFlightCatalog() {
        return airlinerFlightCatalog;
    }

    public void setFlightCatalog(FlightCatalog flightCatalog) {
        this.airlinerFlightCatalog = flightCatalog;
    }

    public String getName() {
        return airlinerName;
    }

    public void setName(String name) {
        this.airlinerName = name;
    }

    public int getId() {
        return airlinerID;
    }

    public void setId(int id) {
        this.airlinerID = id;
    }

    public int getCustomerService() {
        return airlinerCustomerService;
    }

    public void setCustomerService(int customerService) {
        this.airlinerCustomerService = customerService;
    }

     @Override
  public String toString()
  {
      return this.airlinerName;
      
   }
}
    

