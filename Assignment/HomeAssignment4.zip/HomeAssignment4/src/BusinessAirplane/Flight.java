/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BusinessAirplane;

import java.util.Date;

/**
 *
 * 
 */
public class Flight {
    private int flightNumber;
    private String flightSerialNumber;
    private String flightName;
    private String flightSource;
    private String flightDestination;
    private String flightLocation;
    private int seats;
    private String modelNumber;
    private int manufactureYear;
    private  String manufactureDetails;
    private int price;
    private Date date;
    private String customer;
    
    
    

    public int getFlightNumber() {
        return flightNumber;
    }

    public void setFlightNumber(int flightNumber) {
        this.flightNumber = flightNumber;
    }

    public String getSerialNumber() {
        return flightSerialNumber;
    }

    public void setSerialNumber(String serialNumber) {
        this.flightSerialNumber = serialNumber;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getCustomer() {
        return customer;
    }

    public void setCustomer(String customer) {
        this.customer = customer;
    }

    public String getFlightName() {
        return flightName;
    }

    public void setFlightName(String flightName) {
        this.flightName = flightName;
    }

    public String getSource() {
        return flightSource;
    }

    public void setSource(String source) {
        this.flightSource = source;
    }

    public String getDestination() {
        return flightDestination;
    }

    public void setDestination(String destination) {
        this.flightDestination = destination;
    }

    public String getLocation() {
        return flightLocation;
    }

    public void setLocation(String location) {
        this.flightLocation = location;
    }

    public int getSeats() {
        return seats;
    }

    public void setSeats(int seats) {
        this.seats = seats;
    }

    public String getModelNumber() {
        return modelNumber;
    }

    public void setModelNumber(String modelNumber) {
        this.modelNumber = modelNumber;
    }

    public int getManufactureYear() {
        return manufactureYear;
    }

    public void setManufactureYear(int manufactureYear) {
        this.manufactureYear = manufactureYear;
    }

    public String getManufactureDetails() {
        return manufactureDetails;
    }

    public void setManufactureDetails(String manufactureDetails) {
        this.manufactureDetails = manufactureDetails;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }
    
        @Override
  public String toString()
  {
      return this.flightName;
   }
    
}
