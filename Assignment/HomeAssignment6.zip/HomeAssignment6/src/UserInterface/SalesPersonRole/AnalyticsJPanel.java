/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package UserInterface.SalesPersonRole;

import Business.OrderItem;
import Business.SalesPerson;
import Business.SalesPersonDirectory;
import Business.Supplier;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.swing.JPanel;
import javax.swing.table.DefaultTableModel;
import static jdk.nashorn.internal.objects.NativeArray.map;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartFrame;
import org.jfree.chart.JFreeChart;
import org.jfree.data.general.DefaultPieDataset;
import org.jfree.data.general.PieDataset;

/**
 *
 * @author Danish
 */
public class AnalyticsJPanel extends javax.swing.JPanel {

    JPanel userProcessContainer;
    SalesPersonDirectory salesPersonDirectory;
    Supplier supplier;

    public AnalyticsJPanel(JPanel userProcessContainer, SalesPersonDirectory salesPersonDirectory, Supplier supplier) {
        initComponents();
        this.userProcessContainer = userProcessContainer;
        this.salesPersonDirectory = salesPersonDirectory;
        this.supplier = supplier;
    }

    private String totRev() {
        int intRev = 0;
        for (SalesPerson s : salesPersonDirectory.getSalesPersonList()) {
            intRev = intRev + s.totalSales();
        }
        return Integer.toString(intRev);
    }

    public LinkedHashMap<Integer, String> sortHashMapByValues(HashMap<Integer, String> passedMap) {
        List<Integer> mapKeys = new ArrayList<>(passedMap.keySet());
        List<String> mapValues = new ArrayList<>(passedMap.values());
        Collections.sort(mapValues);
        Collections.sort(mapKeys);

        LinkedHashMap<Integer, String> sortedMap = new LinkedHashMap<>();

        Iterator<String> valueIt = mapValues.iterator();
        while (valueIt.hasNext()) {
            String val = valueIt.next();
            Iterator<Integer> keyIt = mapKeys.iterator();

            while (keyIt.hasNext()) {
                Integer key = keyIt.next();
                String comp1 = passedMap.get(key);
                String comp2 = val;

                if (comp1.equals(comp2)) {
                    keyIt.remove();
                    sortedMap.put(key, val);
                    break;
                }
            }
        }
        return sortedMap;
    }

    private DefaultPieDataset topTenSalePersonDataSet() {
        DefaultPieDataset dataset = new DefaultPieDataset();
        HashMap<Integer, String> hm = new HashMap<>();
        HashMap<Integer, String> hm2 = new HashMap<>();
        //TreeMap<String, Integer> hm = new TreeMap<>();
        for (SalesPerson s : salesPersonDirectory.getSalesPersonList()) {
            System.out.println("s.totalSales()>> " + s.totalSales());
            System.out.println("s.getUsername()>> " + s.getUsername());
            hm.put(s.totalSales(), s.getUsername());
        }
        hm2 = sortHashMapByValues(hm);

        for (Map.Entry<Integer, String> entry : hm2.entrySet()) {
            Integer value = entry.getKey();
            String key = entry.getValue();
            System.out.println("key>> " + key);
            System.out.println("value>> " + value);
            dataset.setValue(key, value);
        }

        return dataset;
    }

    private DefaultPieDataset marketSalePersonDataSet() {
        DefaultPieDataset dataset = new DefaultPieDataset();
        int medical = 0;
        int education = 0;
        int financial = 0;

        for (SalesPerson s : salesPersonDirectory.getSalesPersonList()) {

            if (s.getMasterOrderCatalog().getMarkeyType().equalsIgnoreCase("Education")) {
                for (OrderItem o : s.getMasterOrderCatalog().getOrderCatalog().getOrderItemList()) {
                    education = (int) (education + o.getSalesPrice());
                }
            } else if (s.getMasterOrderCatalog().getMarkeyType().equalsIgnoreCase("Medical")) {
                for (OrderItem o : s.getMasterOrderCatalog().getOrderCatalog().getOrderItemList()) {
                    medical = (int) (medical + o.getSalesPrice());
                }
            } else {
                for (OrderItem o : s.getMasterOrderCatalog().getOrderCatalog().getOrderItemList()) {
                    financial = (int) (financial + o.getSalesPrice());
                }
            }
        }
        System.out.println("education>> " + education);
        System.out.println("medical>> " + medical);
        System.out.println("financial>> " + financial);
        dataset.setValue("Education", education);
        dataset.setValue("Medical", medical);
        dataset.setValue("Financial", financial);
        
        return dataset;
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnTotRev = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        txtTotRev = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        btnTopTenSales = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        btnAboveTarget = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblBelowTarget = new javax.swing.JTable();
        jLabel5 = new javax.swing.JLabel();
        btnBelowTarget = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        tblAboveTarget = new javax.swing.JTable();
        jLabel6 = new javax.swing.JLabel();
        btnMarketSales = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();

        setBackground(new java.awt.Color(255, 255, 255));

        btnTotRev.setText("Go");
        btnTotRev.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTotRevActionPerformed(evt);
            }
        });

        jLabel2.setText("Total revenue generated:");

        txtTotRev.setEditable(false);
        txtTotRev.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtTotRevActionPerformed(evt);
            }
        });

        jLabel3.setText("Top 10 Sales Persons:");

        btnTopTenSales.setText("Go");
        btnTopTenSales.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTopTenSalesActionPerformed(evt);
            }
        });

        jLabel4.setText("Sales Person with all selling price above target price: ");

        btnAboveTarget.setText("Go");
        btnAboveTarget.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAboveTargetActionPerformed(evt);
            }
        });

        tblBelowTarget.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Sales Person", "Total Sales"
            }
        ));
        jScrollPane1.setViewportView(tblBelowTarget);

        jLabel5.setText("Sales Person with all selling price below target price: ");

        btnBelowTarget.setText("Go");
        btnBelowTarget.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBelowTargetActionPerformed(evt);
            }
        });

        tblAboveTarget.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Sales Person", "Total Sales"
            }
        ));
        jScrollPane2.setViewportView(tblAboveTarget);

        jLabel6.setText("Sales according to market:");

        btnMarketSales.setText("Go");
        btnMarketSales.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMarketSalesActionPerformed(evt);
            }
        });

        jLabel7.setFont(new java.awt.Font("Tahoma", 0, 22)); // NOI18N
        jLabel7.setText("SALES ANALYSIS");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(344, 344, 344)
                        .addComponent(jLabel7))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel4)
                            .addComponent(jLabel5)
                            .addComponent(jLabel3)
                            .addComponent(jLabel2)
                            .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 308, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnBelowTarget)
                            .addComponent(btnAboveTarget)
                            .addComponent(btnMarketSales)
                            .addComponent(btnTopTenSales)
                            .addComponent(btnTotRev))
                        .addGap(21, 21, 21)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtTotRev, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 356, Short.MAX_VALUE)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))))
                .addContainerGap(156, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(35, 35, 35)
                .addComponent(jLabel7)
                .addGap(27, 27, 27)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnTotRev)
                    .addComponent(txtTotRev, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(btnTopTenSales))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel4)
                        .addComponent(btnAboveTarget))
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(26, 26, 26)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btnBelowTarget)
                        .addComponent(jLabel5))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnMarketSales)
                    .addComponent(jLabel6))
                .addGap(147, 147, 147))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void btnTopTenSalesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTopTenSalesActionPerformed
        DefaultPieDataset pieDataSet = new DefaultPieDataset();
        pieDataSet = topTenSalePersonDataSet();
        JFreeChart chart = ChartFactory.createPieChart("Top 10 Sales Person", pieDataSet, true, true, false);
        //PiePlot3D P = (PiePlot3D) chart.getPlot();
        //P.setForegroundAlpha(TOP_ALIGNMENT);
        ChartFrame frame = new ChartFrame("Top 10 Sales Person", chart);
        frame.setVisible(true);
        frame.setSize(400, 500);

    }//GEN-LAST:event_btnTopTenSalesActionPerformed

    private void txtTotRevActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTotRevActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtTotRevActionPerformed

    private void btnTotRevActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTotRevActionPerformed
        txtTotRev.setText(totRev());
    }//GEN-LAST:event_btnTotRevActionPerformed

    private void btnAboveTargetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAboveTargetActionPerformed
        DefaultTableModel dtm = (DefaultTableModel) tblAboveTarget.getModel();

        for (int i = dtm.getRowCount() - 1; i >= 0; i--) {
            dtm.removeRow(i);
        }
        for (SalesPerson s : salesPersonDirectory.getSalesPersonList()) {
            System.out.println("s.allAboveTarget()>> " + s.allAboveTarget());
            if (s.allAboveTarget()) {
                Object row[] = new Object[2];
                row[0] = s;
                row[1] = s.totalSales();
                dtm.addRow(row);
            }
        }
    }//GEN-LAST:event_btnAboveTargetActionPerformed

    private void btnBelowTargetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBelowTargetActionPerformed
        DefaultTableModel dtm = (DefaultTableModel) tblBelowTarget.getModel();

        for (int i = dtm.getRowCount() - 1; i >= 0; i--) {
            dtm.removeRow(i);
        }

        for (SalesPerson s : salesPersonDirectory.getSalesPersonList()) {
            System.out.println("s.allBelowTarget()>> " + s.allBelowTarget());
            if (s.allBelowTarget()) {
                Object row[] = new Object[2];
                row[0] = s;
                row[1] = s.totalSales();
                dtm.addRow(row);
            }
        }
    }//GEN-LAST:event_btnBelowTargetActionPerformed

    private void btnMarketSalesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMarketSalesActionPerformed
        DefaultPieDataset pieDataSet = new DefaultPieDataset();
        pieDataSet = marketSalePersonDataSet();
        JFreeChart chart = ChartFactory.createPieChart("Market Sales", pieDataSet, true, true, false);
        ChartFrame frame = new ChartFrame("Market Sales", chart);
        frame.setVisible(true);
        frame.setSize(400, 500);
    }//GEN-LAST:event_btnMarketSalesActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAboveTarget;
    private javax.swing.JButton btnBelowTarget;
    private javax.swing.JButton btnMarketSales;
    private javax.swing.JButton btnTopTenSales;
    private javax.swing.JButton btnTotRev;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable tblAboveTarget;
    private javax.swing.JTable tblBelowTarget;
    private javax.swing.JTextField txtTotRev;
    // End of variables declaration//GEN-END:variables

}
