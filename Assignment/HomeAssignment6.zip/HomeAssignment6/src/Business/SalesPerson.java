/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

/**
 *
 * @author Danish
 */
public class SalesPerson {

    String username;
    String name;
    char[] password;
    MasterOrderCatalog masterOrderCatalog;

    public SalesPerson() {
        masterOrderCatalog = new MasterOrderCatalog();
    }

    public MasterOrderCatalog getMasterOrderCatalog() {
        return masterOrderCatalog;
    }

    public void setMasterOrderCatalog(MasterOrderCatalog masterOrderCatalog) {
        this.masterOrderCatalog = masterOrderCatalog;
    }

    public int totalSales() {
        int totSal = 0;
        for (OrderItem or : masterOrderCatalog.getOrderCatalog().getOrderItemList()) {
            totSal = (int) (totSal + or.getSalesPrice());
        }
        return totSal;
    }
    
    public boolean allAboveTarget() {
        boolean flag = true;
        for (OrderItem or : masterOrderCatalog.getOrderCatalog().getOrderItemList()) {
            if(or.getSalesPrice() < or.getProduct().getTragetPrice()){
                flag = false;
                break;        
            }
        }
        return flag;
    }
    public boolean allBelowTarget() {
        boolean flag = true;
        for (OrderItem or : masterOrderCatalog.getOrderCatalog().getOrderItemList()) {
            if(or.getSalesPrice() > or.getProduct().getTragetPrice()){
                flag = false;
                break;        
            }
        }
        return flag;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public char[] getPassword() {
        return password;
    }

    public void setPassword(char[] password) {
        this.password = password;
    }

    @Override
    public String toString() {
        return this.name;
    }

}
