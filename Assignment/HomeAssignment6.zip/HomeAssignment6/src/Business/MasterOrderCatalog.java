/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

/**
 *
 * @author Danish
 */
public class MasterOrderCatalog {
    private Order orderCatalog;
    //private ArrayList<Order> orderCatalogList;
    private String markeyType;
    
    public MasterOrderCatalog(){
        orderCatalog = new Order();
        //orderCatalogList = new ArrayList();
    }

    public String getMarkeyType() {
        return markeyType;
    }

    public void setMarkeyType(String markeyType) {
        this.markeyType = markeyType;
    }
    
    

    public Order getOrderCatalog() {
        return orderCatalog;
    }

    public void setOrderCatalog(Order orderCatalog) {
        this.orderCatalog = orderCatalog;
    }

}
