/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

import java.util.ArrayList;

/**
 *
 * @author Vedant Singhvi
 */
public class TravelAgency {
 
    String travelAgencyName;

    public int getNumberOfAirliners() {
        return numberOfAirliners;
    }

    public void setNumberOfAirliners(int numberOfAirliners) {
        this.numberOfAirliners = numberOfAirliners;
    }
    int numberOfAirliners;
    
    private ArrayList<Customer>customers ;
    private ArrayList<Airliner>travelagency ;
    public TravelAgency()
    {
    travelagency= new ArrayList<Airliner>();
    customers = new ArrayList<Customer>();
    }        

    public String getTravelAgencyName() {
        return travelAgencyName;
    }

    public void setTravelAgencyName(String travelAgencyName) {
        this.travelAgencyName = travelAgencyName;
    }

    public ArrayList<Customer> getCustomers() {
        return customers;
    }

    public void setCustomers(ArrayList<Customer> customers) {
        this.customers = customers;
    }

    public ArrayList<Airliner> getTravelagency() {
        return travelagency;
    }

    public void setTravelagency(ArrayList<Airliner> travelagency) {
        this.travelagency = travelagency;
    }

    
    

       
        
        
        
        
        
    }
    
