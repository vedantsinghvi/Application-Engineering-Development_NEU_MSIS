/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;
import Business.Airliner;
import java.util.ArrayList;
import Business.Airplane;
import Business.Flight;
import Business.Seats;
import java.io.File;
import java.io.FileNotFoundException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Random;
import java.util.Scanner;


/**
 *
 * @author Vedant Singhvi
 */
public class Configure {
    public void initializeTravelAgency(TravelAgency travelAgency){
        
    ArrayList<Airliner> airliners = travelAgency.getTravelagency();
    ArrayList<Customer> customers = travelAgency.getCustomers();
        
    for (int a=0;a<250;a++) {
      Customer c= new Customer();
      c.setContactNumber(randInt(700000,999999));
      c.setFirstName(randName());
      c.setLastName(randName());
      c.setVerificationID(randInt(40000,80000));
      customers.add(c);
    }
    
    
        
    for (int i = 0; i < 8; i++) {
        Airliner a1= new Airliner();
        a1.setAirlinerID(randInt(10000,99999));
        a1.setAirlinerName(randName());        
        airliners.add(a1);
        ArrayList<Airplane> airplane= a1.getAirliner(); 
            for (int j = 0; j< 16; j++) {
                 Airplane p1= new Airplane();
                 p1.setManufacturer(randName());
                 p1.setModelNumber(randInt(1000,9999));
                 airplane.add(p1);
                 ArrayList<Flight> flight=p1.getAirplane();
                       for (int k = 0; k < 24 ; k++) {
                           Flight f1= new Flight();
                           f1.setDestination(randName());
                           f1.setSource(randName());
                           f1.setDate();
                           f1.setFlightNumber(randInt(100000,999999));   
                           f1.add(flight);
                           ArrayList<Seats> seats= f1.getFlight();
                                for (int l =0; l < 150; l++) {
                                Seats s1=new Seats();
                                s1.setSeatCost(randInt(150,450));
                                s1.setAvailibility();
                                s1.add(seats);
                              
        
            }}}}
        
        
        
        
            Customer c= new Customer();
            c.setContactNumber(i);
            c.setFirstName(randName());
            c.setLastName(randName());
            c.setVerificationID(randInt(40000,80000));
            ArrayList<Customer> customer  = c.getSeats();
            
            
        
        
               
        
        
        
              
               
                
        public static String randName() throws FileNotFoundException {
        File f = new File("names.txt");
        String result = null;
        Random rand = new Random();
        int n = 0;
        for (Scanner sc = new Scanner(f); sc.hasNext();) {
            ++n;
            String line = sc.nextLine();
            if (rand.nextInt(n) == 0) {
                result = line;
            }
        }

        return result;
    }
        
        
        
         public static int randInt(int min, int max) {

        // Usually this can be a field rather than a method variable
        Random rand = new Random();

        // nextInt is normally exclusive of the top value,
        // so add 1 to make it inclusive
        int randomNum = rand.nextInt((max - min) + 1) + min;

        return randomNum;
    }


        public static Date randomDate(int min, int max) throws ParseException {
        GregorianCalendar gc = new GregorianCalendar();
        int year = randInt(min, max);
        gc.set(gc.YEAR, year);
        int dayOfYear = randInt(1, gc.getActualMaximum(gc.DAY_OF_YEAR));
        gc.set(gc.DAY_OF_YEAR, dayOfYear);
        String dateStr = gc.get(gc.YEAR) + "-" + (gc.get(gc.MONTH) + 1) + "-" + gc.get(gc.DAY_OF_MONTH);
        DateFormat df = new SimpleDateFormat("yyyy-mm-dd");
        Date date = df.parse(dateStr);
        return date;
    }


                
                
                
                
                
                
                
        
        
        
        
    }






































