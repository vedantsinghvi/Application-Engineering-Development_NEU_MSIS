/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

import java.util.ArrayList;

/**
 *
 * @author Vedant Singhvi
 */
public class Airliner {
    String airlinerName;
    int airlinerID;
    int numberOfAirplanesInFleet;
    String airlinerRevenue;

    public int getAirlinerID() {
        return airlinerID;
    }

    public void setAirlinerID(int airlinerID) {
        this.airlinerID = airlinerID;
    }
    
         
    private ArrayList<Airplane>airliner ;
    public Airliner()
    {
    airliner= new ArrayList<Airplane>();
    }       
    
    public int getNumberOfAirplanesInFleet() {
        return numberOfAirplanesInFleet;
    }

    public void setNumberOfAirplanesInFleet(int numberOfAirplanesInFleet) {
        this.numberOfAirplanesInFleet = numberOfAirplanesInFleet;
    }

    public ArrayList<Airplane> getAirliner() {
        return airliner;
    }

    public void setAirliner(ArrayList<Airplane> airliner) {
        this.airliner = airliner;
    }
    

    public String getAirlinerName() {
        return airlinerName;
    }

    public void setAirlinerName(String airlinerName) {
        this.airlinerName = airlinerName;
    }

    
    public String getAirlinerRevenue() {
        return airlinerRevenue;
    }

    public void setAirlinerRevenue(String airlinerRevenue) {
        this.airlinerRevenue = airlinerRevenue;
    }

}
