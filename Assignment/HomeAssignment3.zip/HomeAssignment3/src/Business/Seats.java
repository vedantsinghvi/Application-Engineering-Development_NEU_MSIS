/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

import java.util.ArrayList;

/**
 *
 * @author Vedant Singhvi
 */
public class Seats {
    
    int seatNumber;
    
    int seatCost;
    Boolean Availibility;
    int minSeats;
    int maxSeats;
    int seatsRevenue;

    public Boolean getAvailibility() {
        return Availibility;
    }

    public void setAvailibility(Boolean Availibility) {
        this.Availibility = Availibility;
    }

    public int getSeatsRevenue() {
        return seatsRevenue;
    }

    public void setSeatsRevenue(int seatsRevenue) {
        this.seatsRevenue = seatsRevenue;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }
    private Customer customer;
    

    public int getSeatNumber() {
        return seatNumber;
    }

    public void setSeatNumber(int seatNumber) {
        this.seatNumber = seatNumber;
    }


    public int getSeatCost() {
        return seatCost;
    }

    public void setSeatCost(int seatCost) {
        this.seatCost = seatCost;
    }


    public int getMinSeats() {
        return minSeats;
    }

    public void setMinSeats(int minSeats) {
        this.minSeats = minSeats;
    }

    public int getMaxSeats() {
        return maxSeats;
    }

    public void setMaxSeats(int maxSeats) {
        this.maxSeats = maxSeats;
    }

    void add(ArrayList<Seats> seats) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    
}
