/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

import java.util.ArrayList;

/**
 *
 * @author Vedant Singhvi
 */
public class Airplane {
    
    int serialNumber;
    int modelNumber;
    int seatsAvailable;
    String manufacturer;
    String airplaneRevenue;

    public String getAirplaneRevenue() {
        return airplaneRevenue;
    }

    public void setAirplaneRevenue(String airplaneRevenue) {
        this.airplaneRevenue = airplaneRevenue;
    }
    
        
    private ArrayList<Flight>airplane ;
    public Airplane()
    {
    airplane= new ArrayList<Flight>();
    }       

    public int getSerialNumber() {
        return serialNumber;
    }

    public void setSerialNumber(int serialNumber) {
        this.serialNumber = serialNumber;
    }

    public int getModelNumber() {
        return modelNumber;
    }

    public void setModelNumber(int modelNumber) {
        this.modelNumber = modelNumber;
    }

    public int getSeatsAvailable() {
        return seatsAvailable;
    }

    public void setSeatsAvailable(int seatsAvailable) {
        this.seatsAvailable = seatsAvailable;
    }

    public String getManufacturer() {
        return manufacturer;
    }

    public void setManufacturer(String manufacturer) {
        this.manufacturer = manufacturer;
    }

    public ArrayList<Flight> getAirplane() {
        return airplane;
    }

    public void setAirplane(ArrayList<Flight> airplane) {
        this.airplane = airplane;
    }
    
    
    
}