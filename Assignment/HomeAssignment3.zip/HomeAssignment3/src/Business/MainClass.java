/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

import java.util.ArrayList;

/**
 *
 * @author Vedant Singhvi
 */
public class MainClass {
    
    
     public static void main(String[] args) {
        Configure c = new Configure();
        TravelAgency travelagency= new TravelAgency();
        travelagency.setTravelAgencyName("my travel agency");
        c.initializeTravelAgency(travelagency);
        
        
        
        
        
        
        
        
        
        
        
         System.out.println("Choose the action you want to perform:");
        
        
        char grade = 'C';

      switch(grade) {
         case 'A' :
            System.out.println("Travel Agency Revenue"); 
            break;
         case 'B' :
         case 'C' :
            System.out.println("Airliner Revenue");
            break;
         case 'D' :
            System.out.println("Airplane Revenue");
         case 'F' :
            System.out.println("");
            break;
         default :
            System.out.println("");
      }
      System.out.println(" " );
   }

        
        
        
        
        
    }







































