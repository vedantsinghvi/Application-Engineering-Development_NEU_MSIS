/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

import java.util.ArrayList;
import java.util.Date;

/**
 *
 * @author Vedant Singhvi
 */
public class Flight {
    
    int flightNumber;
    String destination;
    String source;
    int timeOfArrival;
    int timeOfDeparture; 
    Date setDate;

    public Date getSetDate() {
        return setDate;
    }

    public void setSetDate(Date setDate) {
        this.setDate = setDate;
    }
    

        
    private ArrayList<Seats>flight ;
    
    public Flight()
    {
    flight= new ArrayList<Seats>();
    }  

    public int getFlightNumber() {
        return flightNumber;
    }

    public void setFlightNumber(int flightNumber) {
        this.flightNumber = flightNumber;
    }

    public String getDestination() {
        return destination;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public int getTimeOfArrival() {
        return timeOfArrival;
    }

    public void setTimeOfArrival(int timeOfArrival) {
        this.timeOfArrival = timeOfArrival;
    }

    public int getTimeOfDeparture() {
        return timeOfDeparture;
    }

    public void setTimeOfDeparture(int timeOfDeparture) {
        this.timeOfDeparture = timeOfDeparture;
    }

    public ArrayList<Seats> getFlight() {
        return flight;
    }

    public void setFlight(ArrayList<Seats> flight) {
        this.flight = flight;
    }

    void add(ArrayList<Flight> flight) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    
    
}
