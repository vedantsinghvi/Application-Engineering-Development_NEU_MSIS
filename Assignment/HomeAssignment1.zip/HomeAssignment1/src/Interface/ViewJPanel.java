/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Interface;

import Object.Person;
import Object.Address;
import Object.CreditCard;
import Object.FinancialAccounts;
import Object.LicenseData;
import javax.swing.ImageIcon;


/**
 *
 * @author Vedant Singhvi
 */
public class ViewJPanel extends javax.swing.JPanel {

    /**
     * Creates new form ViewJPanel
     */
    public ViewJPanel(Person person) {
        initComponents();
        displayPerson(person);
    }

    //To change body of generated methods, choose Tools | Templates.
    
    
    
    private void displayPerson(Person person)
    {
        
        String personFirstName=person.getFirstName();
        firstNameTextField.setText(personFirstName);
        
        String personLastName=person.getLastName();
        lastNameTextField.setText(personLastName);
        
        String personGender=person.getGender();
        genderTextField.setText(personGender);
               
        String personNationality=person.getNationality();
        nationalityTextField.setText(personNationality);
        
        String personDob=person.getDob();
        dobTextField.setText(personDob);
        
        
        
      
        String im=person.getImage();
       
        ImageIcon icn= new ImageIcon(im);
        imageUploadTextField.setIcon(icn);
        
        
        
        
        
         Address address=person.getAddress();
         
         String addressStreet1=address.getStreet1();
         street1TextField.setText(addressStreet1);
         
         String addressStreet2=address.getStreet2();
         street2TextField.setText(addressStreet2);
         
         String addresscityName=address.getCityName();
         cityTextField.setText(addresscityName);
         
         String addressStateName=address.getStateName();
         stateTextField.setText(addressStateName);
         
         String addressZipCode=address.getZipCode();
         zipCodeTextField.setText(addressZipCode);
         
         
         
         
        
         FinancialAccounts financialaccounts=person.getFinancialaccounts();
         
         String financialaccountsBankName=financialaccounts.getBankName();
         bankNameTextField.setText(financialaccountsBankName);
         
         String financialaccountsAccountType=financialaccounts.getAccountType();
         accountTypeTextField.setText(financialaccountsAccountType);
         
         String financialaccountsAccountHolder=financialaccounts.getAccountHolder();
         accountHolderNameTextField.setText(financialaccountsAccountHolder);
         
         String financialaccountsAccountNumber=financialaccounts.getAccountNumber();
         accountNumberTextField.setText(financialaccountsAccountNumber);
         
         String financialaccountsRoutingNumber=financialaccounts.getRoutingNumber();
         routingNumberTextField.setText(financialaccountsRoutingNumber);
         
         
         
         
         
         
         LicenseData licensedata=person.getLicensedata();
         
          String licensedataLicenseNumber=licensedata.getLicenseNumber();
         licenseNumberTextField.setText(licensedataLicenseNumber);
         
          String licensedataLicenseType=licensedata.getLicenseType();
         licenseTypeTextField.setText(licensedataLicenseType);
         
           String licensedataSSN=licensedata.getSSN();
         ssnTextField.setText(licensedataSSN);
         
           String licensedataIssueDate=licensedata.getIssueDate();
         issueDateTextField.setText(licensedataIssueDate);
         
           String licensedataExpiryDate=licensedata.getExpiryDate();
         expiryDateTextField.setText(licensedataExpiryDate);
         
         
         
          CreditCard creditcard=person.getCreditcard();
          
          String creditcardCardType=creditcard.getCardType();
          cardTypeTextField.setText(creditcardCardType);
          
          String creditcardNumber=creditcard.getNumber();
          cardNumberTextField.setText(creditcardNumber);
          
          String creditcardExpiryDate=creditcard.getExpiryDate();
          cardExpiryDateTextField.setText(creditcardExpiryDate);
          
          String creditcardregisteredEmailid=creditcard.getRegisteredeEmailid();
          cardExpiryDateTextField.setText(creditcardregisteredEmailid);
          
          String creditcardregisteredPhone=creditcard.getRegisteredPhone();
          phoneNumberTextField.setText(creditcardregisteredPhone);
          
          
          
          
          
         
         
         
         
         
         
         
         
         
         
         
         
      
         
         //String addressStateName=Address.getStateName();
         
         
         
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        accountHolderNameTextField = new javax.swing.JTextField();
        routingNumberTextField = new javax.swing.JTextField();
        accountNumberTextField = new javax.swing.JTextField();
        CardDetailsLabel = new javax.swing.JLabel();
        CardNumberTxtField = new javax.swing.JLabel();
        CardTypeTxtField = new javax.swing.JLabel();
        RegisteredEmailIDTxtField = new javax.swing.JLabel();
        ExpiryDateCardTxtField = new javax.swing.JLabel();
        RegisteredPhoneNumberTxtField = new javax.swing.JLabel();
        cardTypeTextField = new javax.swing.JTextField();
        PersonalInformationLabel = new javax.swing.JLabel();
        LastNameTxtField = new javax.swing.JLabel();
        firstNameTxtField = new javax.swing.JLabel();
        NationalityTxtField = new javax.swing.JLabel();
        GenderTxtField = new javax.swing.JLabel();
        DOBTxtField = new javax.swing.JLabel();
        firstNameTextField = new javax.swing.JTextField();
        lastNameTextField = new javax.swing.JTextField();
        AddressLabel = new javax.swing.JLabel();
        dobTextField = new javax.swing.JTextField();
        Street2TxtField = new javax.swing.JLabel();
        nationalityTextField = new javax.swing.JTextField();
        Street1TxtField = new javax.swing.JLabel();
        LicenseInformationLabel = new javax.swing.JLabel();
        SSNTxtField = new javax.swing.JLabel();
        LicenseNumberTxtField = new javax.swing.JLabel();
        ExpiryDateTxtField = new javax.swing.JLabel();
        IssueNameTxtField = new javax.swing.JLabel();
        LicenseTypeTxtField = new javax.swing.JLabel();
        StateTxtField = new javax.swing.JLabel();
        CityTxtField = new javax.swing.JLabel();
        ZipCodeTxtField = new javax.swing.JLabel();
        street1TextField = new javax.swing.JTextField();
        street2TextField = new javax.swing.JTextField();
        cityTextField = new javax.swing.JTextField();
        zipCodeTextField = new javax.swing.JTextField();
        stateTextField = new javax.swing.JTextField();
        FinancialDetailsLabel = new javax.swing.JLabel();
        AccountHolderNameTxtField = new javax.swing.JLabel();
        BankNameTxtField = new javax.swing.JLabel();
        AccountNumberTxtField = new javax.swing.JLabel();
        AccountTypeTxtField = new javax.swing.JLabel();
        RoutingNumberTxtField = new javax.swing.JLabel();
        bankNameTextField = new javax.swing.JTextField();
        IssuePlaceTxtField = new javax.swing.JLabel();
        licenseNumberTextField = new javax.swing.JTextField();
        ssnTextField = new javax.swing.JTextField();
        issueDateTextField = new javax.swing.JTextField();
        expiryDateTextField = new javax.swing.JTextField();
        licenseTypeTextField = new javax.swing.JTextField();
        issuePlaceTextField = new javax.swing.JTextField();
        cardNumberTextField = new javax.swing.JTextField();
        cardExpiryDateTextField = new javax.swing.JTextField();
        emailIDTextField = new javax.swing.JTextField();
        phoneNumberTextField = new javax.swing.JTextField();
        genderTextField = new javax.swing.JTextField();
        accountTypeTextField = new javax.swing.JTextField();
        imageUploadTextField = new javax.swing.JLabel();

        routingNumberTextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                routingNumberTextFieldActionPerformed(evt);
            }
        });

        CardDetailsLabel.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        CardDetailsLabel.setText("Card Details");

        CardNumberTxtField.setText("Card  Number");

        CardTypeTxtField.setText("Card Type");

        RegisteredEmailIDTxtField.setText("Registered E-mail ID");

        ExpiryDateCardTxtField.setText("Expiry Date (MM/YY)");

        RegisteredPhoneNumberTxtField.setText("Registered Phone Number");

        cardTypeTextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cardTypeTextFieldActionPerformed(evt);
            }
        });

        PersonalInformationLabel.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        PersonalInformationLabel.setText("Personal Information");

        LastNameTxtField.setText("Last Name");

        firstNameTxtField.setText("First Name");

        NationalityTxtField.setText("Nationality");

        GenderTxtField.setText("Gender");

        DOBTxtField.setText("DOB (MM/DD/YY)");

        firstNameTextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                firstNameTextFieldActionPerformed(evt);
            }
        });

        lastNameTextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                lastNameTextFieldActionPerformed(evt);
            }
        });

        AddressLabel.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        AddressLabel.setText("Address");

        dobTextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dobTextFieldActionPerformed(evt);
            }
        });

        Street2TxtField.setText("Street 2");

        Street1TxtField.setText("Street 1");

        LicenseInformationLabel.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        LicenseInformationLabel.setText("License Information");

        SSNTxtField.setText("SSN");

        LicenseNumberTxtField.setText("License Number");

        ExpiryDateTxtField.setText("Expiry Date (MM/DD/YY)");

        IssueNameTxtField.setText("Issue Date (MM/DD/YY)");

        LicenseTypeTxtField.setText("License Type");

        StateTxtField.setText("State");

        CityTxtField.setText("City");

        ZipCodeTxtField.setText("Zip Code");

        cityTextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cityTextFieldActionPerformed(evt);
            }
        });

        FinancialDetailsLabel.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        FinancialDetailsLabel.setText("Financial Details");

        AccountHolderNameTxtField.setText("Account Holder Name");

        BankNameTxtField.setText("Bank Name");

        AccountNumberTxtField.setText("Account Number");

        AccountTypeTxtField.setText("Account Type");

        RoutingNumberTxtField.setText("Routing Number");

        IssuePlaceTxtField.setText("Issue Place");

        ssnTextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ssnTextFieldActionPerformed(evt);
            }
        });

        cardNumberTextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cardNumberTextFieldActionPerformed(evt);
            }
        });

        phoneNumberTextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                phoneNumberTextFieldActionPerformed(evt);
            }
        });

        imageUploadTextField.setFont(new java.awt.Font("Tahoma", 0, 20)); // NOI18N
        imageUploadTextField.setText("Uploaded Image");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(53, 53, 53)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(15, 15, 15)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(CardTypeTxtField)
                                            .addComponent(CardNumberTxtField))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 20, Short.MAX_VALUE)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(cardNumberTextField, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(cardTypeTextField, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addComponent(RegisteredEmailIDTxtField)
                                            .addComponent(ExpiryDateCardTxtField))
                                        .addGap(18, 18, 18)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(cardExpiryDateTextField)
                                            .addComponent(emailIDTextField)))
                                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                        .addGap(2, 2, 2)
                                        .addComponent(RegisteredPhoneNumberTxtField)
                                        .addGap(18, 18, 18)
                                        .addComponent(phoneNumberTextField))
                                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                        .addComponent(CardDetailsLabel)
                                        .addGap(0, 0, Short.MAX_VALUE)))
                                .addGap(149, 149, 149))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(RoutingNumberTxtField)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(routingNumberTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 199, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(BankNameTxtField)
                                        .addComponent(FinancialDetailsLabel)
                                        .addGroup(layout.createSequentialGroup()
                                            .addComponent(AccountTypeTxtField)
                                            .addGap(29, 29, 29)
                                            .addComponent(accountTypeTextField))
                                        .addGroup(layout.createSequentialGroup()
                                            .addComponent(AccountHolderNameTxtField)
                                            .addGap(18, 18, 18)
                                            .addComponent(accountHolderNameTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                .addGap(0, 0, Short.MAX_VALUE)))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(77, 77, 77)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(AddressLabel, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addGroup(layout.createSequentialGroup()
                                            .addComponent(Street1TxtField)
                                            .addGap(18, 18, 18)
                                            .addComponent(street1TextField, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addGroup(layout.createSequentialGroup()
                                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                            .addComponent(Street2TxtField)
                                                            .addComponent(CityTxtField))
                                                        .addGap(18, 18, 18))
                                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                                        .addComponent(StateTxtField)
                                                        .addGap(38, 38, 38)))
                                                .addGroup(layout.createSequentialGroup()
                                                    .addComponent(ZipCodeTxtField)
                                                    .addGap(10, 10, 10)))
                                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                                .addComponent(zipCodeTextField, javax.swing.GroupLayout.DEFAULT_SIZE, 168, Short.MAX_VALUE)
                                                .addComponent(cityTextField)
                                                .addComponent(street2TextField)
                                                .addComponent(stateTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE))))))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(69, 69, 69)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(206, 206, 206)
                                        .addComponent(issueDateTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(IssueNameTxtField)
                                            .addComponent(ExpiryDateTxtField))
                                        .addGap(30, 30, 30)
                                        .addComponent(expiryDateTextField))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                                .addComponent(SSNTxtField)
                                                .addGap(110, 110, 110))
                                            .addGroup(layout.createSequentialGroup()
                                                .addComponent(LicenseNumberTxtField)
                                                .addGap(26, 26, 26)))
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(licenseNumberTextField)
                                            .addComponent(ssnTextField)))
                                    .addComponent(LicenseInformationLabel)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(IssuePlaceTxtField)
                                            .addComponent(LicenseTypeTxtField))
                                        .addGap(31, 31, 31)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(licenseTypeTextField)
                                            .addComponent(issuePlaceTextField)))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                        .addComponent(imageUploadTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 175, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(70, 70, 70)))))
                        .addGap(163, 163, 163))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(bankNameTextField, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 215, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGroup(layout.createSequentialGroup()
                                    .addGap(11, 11, 11)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(firstNameTxtField)
                                        .addComponent(LastNameTxtField)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                            .addGroup(layout.createSequentialGroup()
                                                .addComponent(DOBTxtField)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addComponent(dobTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 157, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(layout.createSequentialGroup()
                                                .addComponent(GenderTxtField)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addComponent(genderTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 211, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(layout.createSequentialGroup()
                                                .addComponent(NationalityTxtField)
                                                .addGap(18, 18, 18)
                                                .addComponent(nationalityTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 209, javax.swing.GroupLayout.PREFERRED_SIZE))))))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(AccountNumberTxtField)
                                .addGap(18, 18, 18)
                                .addComponent(accountNumberTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 197, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(84, 84, 84)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(PersonalInformationLabel)
                        .addGroup(layout.createSequentialGroup()
                            .addGap(114, 114, 114)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(firstNameTextField, javax.swing.GroupLayout.DEFAULT_SIZE, 193, Short.MAX_VALUE)
                                .addComponent(lastNameTextField))))
                    .addContainerGap(715, Short.MAX_VALUE)))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(30, 30, 30)
                        .addComponent(AddressLabel)
                        .addGap(23, 23, 23)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(Street1TxtField)
                            .addComponent(street1TextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(Street2TxtField)
                            .addComponent(street2TextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(CityTxtField)
                            .addComponent(cityTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(StateTxtField)
                            .addComponent(stateTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(ZipCodeTxtField)
                            .addComponent(zipCodeTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                        .addGap(67, 67, 67)
                        .addComponent(firstNameTxtField)
                        .addGap(18, 18, 18)
                        .addComponent(LastNameTxtField)
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(GenderTxtField)
                            .addComponent(genderTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(NationalityTxtField)
                            .addComponent(nationalityTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(dobTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(DOBTxtField))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 34, Short.MAX_VALUE)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 40, Short.MAX_VALUE)
                        .addComponent(FinancialDetailsLabel)
                        .addGap(23, 23, 23)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(BankNameTxtField)
                            .addComponent(bankNameTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(AccountHolderNameTxtField)
                            .addComponent(accountHolderNameTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(AccountTypeTxtField)
                            .addComponent(accountTypeTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(AccountNumberTxtField)
                            .addComponent(accountNumberTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(RoutingNumberTxtField)
                            .addComponent(routingNumberTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(77, 77, 77)
                        .addComponent(CardDetailsLabel)
                        .addGap(18, 18, 18))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(26, 26, 26)
                        .addComponent(LicenseInformationLabel)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(LicenseNumberTxtField)
                            .addComponent(licenseNumberTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(11, 11, 11)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(SSNTxtField)
                            .addComponent(ssnTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(IssueNameTxtField)
                            .addComponent(issueDateTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(7, 7, 7)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(ExpiryDateTxtField)
                            .addComponent(expiryDateTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(LicenseTypeTxtField)
                            .addComponent(licenseTypeTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(issuePlaceTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(IssuePlaceTxtField))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(CardTypeTxtField)
                    .addComponent(cardTypeTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(21, 21, 21)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(CardNumberTxtField)
                    .addComponent(cardNumberTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(ExpiryDateCardTxtField)
                            .addComponent(cardExpiryDateTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(RegisteredEmailIDTxtField)
                            .addComponent(emailIDTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(imageUploadTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(RegisteredPhoneNumberTxtField)
                    .addComponent(phoneNumberTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(216, 216, 216))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(PersonalInformationLabel)
                    .addGap(24, 24, 24)
                    .addComponent(firstNameTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                    .addComponent(lastNameTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(976, Short.MAX_VALUE)))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void routingNumberTextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_routingNumberTextFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_routingNumberTextFieldActionPerformed

    private void cardTypeTextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cardTypeTextFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cardTypeTextFieldActionPerformed

    private void firstNameTextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_firstNameTextFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_firstNameTextFieldActionPerformed

    private void lastNameTextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_lastNameTextFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_lastNameTextFieldActionPerformed

    private void dobTextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dobTextFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_dobTextFieldActionPerformed

    private void cityTextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cityTextFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cityTextFieldActionPerformed

    private void ssnTextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ssnTextFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ssnTextFieldActionPerformed

    private void cardNumberTextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cardNumberTextFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cardNumberTextFieldActionPerformed

    private void phoneNumberTextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_phoneNumberTextFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_phoneNumberTextFieldActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel AccountHolderNameTxtField;
    private javax.swing.JLabel AccountNumberTxtField;
    private javax.swing.JLabel AccountTypeTxtField;
    private javax.swing.JLabel AddressLabel;
    private javax.swing.JLabel BankNameTxtField;
    private javax.swing.JLabel CardDetailsLabel;
    private javax.swing.JLabel CardNumberTxtField;
    private javax.swing.JLabel CardTypeTxtField;
    private javax.swing.JLabel CityTxtField;
    private javax.swing.JLabel DOBTxtField;
    private javax.swing.JLabel ExpiryDateCardTxtField;
    private javax.swing.JLabel ExpiryDateTxtField;
    private javax.swing.JLabel FinancialDetailsLabel;
    private javax.swing.JLabel GenderTxtField;
    private javax.swing.JLabel IssueNameTxtField;
    private javax.swing.JLabel IssuePlaceTxtField;
    private javax.swing.JLabel LastNameTxtField;
    private javax.swing.JLabel LicenseInformationLabel;
    private javax.swing.JLabel LicenseNumberTxtField;
    private javax.swing.JLabel LicenseTypeTxtField;
    private javax.swing.JLabel NationalityTxtField;
    private javax.swing.JLabel PersonalInformationLabel;
    private javax.swing.JLabel RegisteredEmailIDTxtField;
    private javax.swing.JLabel RegisteredPhoneNumberTxtField;
    private javax.swing.JLabel RoutingNumberTxtField;
    private javax.swing.JLabel SSNTxtField;
    private javax.swing.JLabel StateTxtField;
    private javax.swing.JLabel Street1TxtField;
    private javax.swing.JLabel Street2TxtField;
    private javax.swing.JLabel ZipCodeTxtField;
    private javax.swing.JTextField accountHolderNameTextField;
    private javax.swing.JTextField accountNumberTextField;
    private javax.swing.JTextField accountTypeTextField;
    private javax.swing.JTextField bankNameTextField;
    private javax.swing.JTextField cardExpiryDateTextField;
    private javax.swing.JTextField cardNumberTextField;
    private javax.swing.JTextField cardTypeTextField;
    private javax.swing.JTextField cityTextField;
    private javax.swing.JTextField dobTextField;
    private javax.swing.JTextField emailIDTextField;
    private javax.swing.JTextField expiryDateTextField;
    private javax.swing.JTextField firstNameTextField;
    private javax.swing.JLabel firstNameTxtField;
    private javax.swing.JTextField genderTextField;
    private javax.swing.JLabel imageUploadTextField;
    private javax.swing.JTextField issueDateTextField;
    private javax.swing.JTextField issuePlaceTextField;
    private javax.swing.JTextField lastNameTextField;
    private javax.swing.JTextField licenseNumberTextField;
    private javax.swing.JTextField licenseTypeTextField;
    private javax.swing.JTextField nationalityTextField;
    private javax.swing.JTextField phoneNumberTextField;
    private javax.swing.JTextField routingNumberTextField;
    private javax.swing.JTextField ssnTextField;
    private javax.swing.JTextField stateTextField;
    private javax.swing.JTextField street1TextField;
    private javax.swing.JTextField street2TextField;
    private javax.swing.JTextField zipCodeTextField;
    // End of variables declaration//GEN-END:variables
}
