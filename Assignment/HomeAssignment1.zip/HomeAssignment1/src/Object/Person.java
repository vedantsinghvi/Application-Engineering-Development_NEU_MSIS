/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Object;

/**
 *
 * @author Vedant Singhvi
 */
public class Person {
    
    private String firstName;
    private String lastName;
    private String gender;
    private String nationality;
    private String emailAddress;
    private String dob;

    public Address address;
    public CreditCard creditcard;
    public FinancialAccounts financialaccounts;
    public LicenseData licensedata;
    private String image;

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    
    

    public Address getAddress() {
        return address;
    }

    public void setAddress(Address address) {
        this.address = address;
    }

    public CreditCard getCreditcard() {
        return creditcard;
    }

    public void setCreditcard(CreditCard creditcard) {
        this.creditcard = creditcard;
    }

    public FinancialAccounts getFinancialaccounts() {
        return financialaccounts;
    }

    public void setFinancialaccounts(FinancialAccounts financialaccounts) {
        this.financialaccounts = financialaccounts;
    }

    public LicenseData getLicensedata() {
        return licensedata;
    }

    public void setLicensedata(LicenseData licensedata) {
        this.licensedata = licensedata;
    }
    

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getNationality() {
        return nationality;
    }

    public void setNationality(String nationality) {
        this.nationality = nationality;
    }

    public String getEmailAddress() {
        return emailAddress;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    public String getDob() {
        return dob;
    }

    public void setDob(String dob) {
        this.dob = dob;
    }


    
}
