/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Object;

/**
 *
 * @author Vedant Singhvi
 */
public class CreditCard {
    
    private String cardType;
    private String number;
    private String expiryDate;
    private String registeredeEmailid;
    private String registeredPhone;

    public String getCardType() {
        return cardType;
    }

    public void setCardType(String cardType) {
        this.cardType = cardType;
    }

    public String getExpiryDate() {
        return expiryDate;
    }

    public void setExpiryDate(String expiryDate) {
        this.expiryDate = expiryDate;
    }

    public String getRegisteredeEmailid() {
        return registeredeEmailid;
    }

    public void setRegisteredeEmailid(String registeredeEmailid) {
        this.registeredeEmailid = registeredeEmailid;
    }

    public String getRegisteredPhone() {
        return registeredPhone;
    }

    public void setRegisteredPhone(String registeredPhone) {
        this.registeredPhone = registeredPhone;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

   
    
}
