/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;
import java.util.ArrayList;
import Business.Airlines;

public class AirlinesHistory {

    private ArrayList<Airlines> airlinesHistory;
    public AirlinesHistory()
    {
    airlinesHistory= new ArrayList<Airlines>();
    }        

    
    public ArrayList<Airlines> getAirlinesHistory() {
        return airlinesHistory;
    }
    public void setAirlinesHistory(ArrayList<Airlines> airlinesHistory) {
        this.airlinesHistory = airlinesHistory;
    }

    
      public Airlines addAirlines()
    {
        Airlines a= new Airlines();
        airlinesHistory.add(a);
        return a;
    }
   
      
     public void deleteAirlines(Airlines a)
     {
        airlinesHistory.remove(a);
     }
    
}
