/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

/**
 *
 * @author Vedant Singhvi
 */
public class Airlines {
    private String modelNumber;
    private String serialNumber;
    private String manufacturerName;
    private String seatsAvailibility;
    private String maintenanceCertificate;
    private String planeAvailable;
    private String manufactureYear;
    private String planeCurrentlyAvailable;
    private String source;
    private String destination;
    

    public String getModelNumber() {
        return modelNumber;
    }
    public void setModelNumber(String modelNumber) {
        this.modelNumber = modelNumber;
    }

    
    public String getSerialNumber() {
        return serialNumber;
    }
    public void setSerialNumber(String serialNumber) {
        this.serialNumber = serialNumber;
    }

    
    public String getManufacturerName() {
        return manufacturerName;
    }
    public void setManufacturerName(String manufacturerName) {
        this.manufacturerName = manufacturerName;
    }

    
    public String getSeatsAvailibility() {
        return seatsAvailibility;
    }
    public void setSeatsAvailibility(String seatsAvailibility) {
        this.seatsAvailibility = seatsAvailibility;
    }

    
    public String getMaintenanceCertificate() {
        return maintenanceCertificate;
    }
    public void setMaintenanceCertificate(String maintenanceCertificate) {
        this.maintenanceCertificate = maintenanceCertificate;
    }

    
    public String getPlaneAvailable() {
        return planeAvailable;
    }
    public void setPlaneAvailable(String planeAvailable) {
        this.planeAvailable = planeAvailable;
    }

    
    public String getManufactureYear() {
        return manufactureYear;
    }
    public void setManufactureYear(String manufactureYear) {
        this.manufactureYear = manufactureYear;
    }

    
    public String getPlaneCurrentlyAvailable() {
        return planeCurrentlyAvailable;
    }
    public void setPlaneCurrentlyAvailable(String planeCurrentlyAvailable) {
        this.planeCurrentlyAvailable = planeCurrentlyAvailable;
    }

    
    public String getSource() {
        return source;
    }
    public void setSource(String source) {
        this.source = source;
    }

    public String getDestination() {
        return destination;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }


 @Override
    public String toString()
    {
        return this.modelNumber;
    }
}  