/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;
import java.util.ArrayList;

/**
 *
 * @author Vedant Singhvi
 */
public class UserAccountDirectory {
    private ArrayList<UserAccount>userAccountList;
    public UserAccountDirectory()
    {
        userAccountList= new ArrayList<UserAccount>();
    }

    public ArrayList<UserAccount> getUserAccountList() {
        return userAccountList;
    }

    public void setUserAccountList(ArrayList<UserAccount> UserAccountList) {
        this.userAccountList = UserAccountList;
    }
     public UserAccount addAccount(){
        UserAccount account=new UserAccount();
        userAccountList.add(account);
        return account;
    }
     
    public UserAccount searchAccount(String userName){
        for(UserAccount account: userAccountList)
        {
            if(account.getUserName().equals(userName)){
                return account;
            }
                
        }
        return null;
    }
    
    
    
}
