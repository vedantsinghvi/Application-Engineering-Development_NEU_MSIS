/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;
import java.util.ArrayList;

/**
 *
 * @author Vedant Singhvi
 */
public class PersonDirectory {
    private ArrayList<Person>PersonList;
    public PersonDirectory()
    {
      PersonList=new ArrayList<Person>();
    }

    public ArrayList<Person> getPersonList() {
        return PersonList;
    }

    public void setPersonList(ArrayList<Person> PersonList) {
        this.PersonList = PersonList;
    }
    public Person addPerson(){
        Person person=new Person();
        PersonList.add(person);
        return person;
    }
    public void deleteAccount(Person person){
        PersonList.remove(person);
         
    }
    public Person searchPerson(String firstName){
        for(Person person: PersonList)
        {
            if(person.getFirstName().equals(firstName)){
                return person;
            }
                
        }
        return null;
    }
    
}
