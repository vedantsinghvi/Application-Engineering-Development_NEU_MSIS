/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

/**
 *
 * @author Vedant Singhvi
 */
public class Business {
    private PersonDirectory perdir;
    private UserAccountDirectory uadir;
    
    public Business() 
    {
        perdir = new PersonDirectory();
        uadir = new UserAccountDirectory();
    }

    public PersonDirectory getPerdir() {
        return perdir;
    }

    public void setPerdir(PersonDirectory perdir) {
        this.perdir = perdir;
    }

    public UserAccountDirectory getUadir() {
        return uadir;
    }

    public void setUadir(UserAccountDirectory uadir) {
        this.uadir = uadir;
    }
    
}
