/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

import java.util.ArrayList;

/**
 *
 * @author Vedant Singhvi
 */
public class Person {
    private String userName;
    private String firstName;
    private String lastName;
    
    private ArrayList<UserAccount> uadArray;

    public Person() 
    {
        //ua = new UserAccounts();
        uadArray = new ArrayList<UserAccount>();
    }

    public ArrayList<UserAccount> getUadArray() {
        return uadArray;
    }

    public void setUadArray(ArrayList<UserAccount> uadArray) {
        this.uadArray = uadArray;
    }
    

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
    @Override
    public String toString()
    {
        return firstName;
    }
    
    public void addToPerson(UserAccount userAccount)
    {
        uadArray.add(userAccount);
    }
    
    
}
