/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

/**
 *
 * @author Vedant Singhvi
 */
public class ConfigureBusiness {
    public static Business initialize()
    {
        Business business = new Business();
        
        PersonDirectory perdir = business.getPerdir();
        
        Person p1 = perdir.addPerson();
        p1.setFirstName("Vedant");
        p1.setLastName("Singhvi");
        
        
        
        
        Person p2 = perdir.addPerson();
        p2.setFirstName("Ved");
        p2.setLastName("Ant");
        
 
 
        
        UserAccountDirectory uadir1 = business.getUadir();
        UserAccount ua1 = uadir1.addAccount();
        ua1.setUserName("Vedant");
        ua1.setPassword("Singhvi");
        ua1.setAccountRole("Admin");
        ua1.setAccountStatus(Boolean.TRUE);
       
        
        ua1.setPerson(p1);
        p1.addToPerson(ua1);
        
       
        
        UserAccountDirectory uadir2 = business.getUadir();
        UserAccount ua2 = uadir2.addAccount();
        ua2.setUserName("Ved");
        ua2.setPassword("Ant");
        ua2.setAccountRole("HR");
        ua2.setAccountStatus(Boolean.TRUE);
        
        ua2.setPerson(p2);
        p2.addToPerson(ua2);
        
       
        
        
        return business;
                
        
    }
    
}
