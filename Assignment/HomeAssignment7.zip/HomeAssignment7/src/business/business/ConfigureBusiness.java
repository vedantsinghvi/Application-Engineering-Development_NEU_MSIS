
package business.business;

import business.Employee.Employee;
import business.Role.SystemAdminRole;
import business.userAccounts.UserAccount;


public class ConfigureBusiness{
    
    public static Business configure(){
    Business business = Business.createInstance();
    Employee employee = business.getEmployeeDirectory().createEmployee("Danish Siddiqui");
//    Enterprise e = new Enterprise(Organization.Type.SystemAdmin.getValue());
//    e.getOrganizationDirectory().createOrganization(Organization.Type.SystemAdmin);
    //Network network = business.createCountry("UN");
    UserAccount user = business.getUserAccountDirectory().createUserAccount("system", "system", new SystemAdminRole(),employee);
    
    return business;
    }
    
}
