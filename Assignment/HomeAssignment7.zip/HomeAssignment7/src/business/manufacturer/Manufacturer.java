/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


package business.Manufacturer;

import business.Employee.Employee;
import business.Organization.ManufacturerOrganization;

public class Manufacturer{
    private String name;

    //private VaccineCatalog vaccineCatalog;
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    
}
