/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.BuyAutomobile;

import Business.Automobile.Automobile;

/**
 *
 * @author Vedant Singhvi
 */
public class OrderItem {
  
   
    private int price;
    private Automobile automobile;
    private int quantity;

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }


    public int getPrice() {
        return price;
    }

    public void setPrice(int Price) {
        this.price = Price;
    }

    public Automobile getAutomobile() {
        return automobile;
    }

    public void setProduct(Automobile automobile) {
        this.automobile = automobile;
    }
    
    @Override
    public String toString() {
        return automobile.getName();
    }
}
