/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Automobile;

import Business.Automobile.Automobile;
import java.util.ArrayList;

/**
 *
 * @author Vedant Singhvi
 */
public class Emission {
    
   
    private int milesDriven;
    private int gallonsConsumed;
    private Double efficiency;
    private ArrayList<Boolean> Accelerator;
    private ArrayList<Boolean> Clutch;
    private ArrayList<Boolean> Brakes;
    
    private int id;
    private static int count = 1;

    public Emission() {
        id = count;
        count++;
        milesDriven = 0;
        gallonsConsumed = 0;
        Accelerator = new ArrayList<Boolean>();
        Clutch = new ArrayList<Boolean>();
        Brakes = new ArrayList<Boolean>();
    }

    
    public int getMilesDriven() {
        return milesDriven;
    }

    public void setMilesDriven(int milesDriven) {
        this.milesDriven = milesDriven;
    }

    public void updateMilesDriven(int milesDriven) {
            this.milesDriven += milesDriven;
        }

    public Double getEfficiency() {
        if(gallonsConsumed==0)
            return 0d;
        efficiency = 1.0*milesDriven/gallonsConsumed;
        return efficiency;
    }

    public ArrayList<Boolean> getAccelerator() {
        return Accelerator;
    }

    public void setAccelerator(ArrayList<Boolean> Accelerator) {
        this.Accelerator = Accelerator;
    }

    public ArrayList<Boolean> getClutch() {
        return Clutch;
    }

    public void setClutch(ArrayList<Boolean> Clutch) {
        this.Clutch = Clutch;
    }

    public ArrayList<Boolean> getBrakes() {
        return Brakes;
    }

    public void setBrakes(ArrayList<Boolean> Brakes) {
        this.Brakes = Brakes;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public static int getCount() {
        return count;
    }

    public static void setCount(int count) {
        Emission.count = count;
    }
    
    public int getGallonsConsumed() {
        return gallonsConsumed;
    }

    public void setGallonsConsumed(int gallonsConsumed) {
        this.gallonsConsumed = gallonsConsumed;
    }
    
    public void updateGallonsConsumed(int gallonsConsumed) {
        this.gallonsConsumed += gallonsConsumed;
    }
}
