/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Automobile;

import Business.EcoSystem;
import Business.Organization.AutomotiveDealerOrganization;
import Business.Role.Customer;
import Business.UserAccount.UserAccount;

/**
 *
 * @author Vedant Singhvi
 */
public class Automobile {

    private String companyName;
    private String name;
    private String engineCapacity;
    private String gearBoxType;
    private float efficiency;
    private int id;
    private int price;
    private Emission emission;
    private int availibility;
    private UserAccount owner;
    private EcoSystem system;
    
    public Automobile(){
        emission = new Emission();
        id = count;
        count++;
    }
    
    public int getAvailibility() {
        return availibility;
    }

    public void setAvailibility(int availibility) {
        this.availibility = availibility;
    }
    
    private static int count =0;
    
    public Emission getEmission() {
        return emission;
    }

    public void setEmission(Emission emission) {
        this.emission = emission;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public AutomotiveDealerOrganization getAutomotiveDealerOrganization() {
        return automotiveDealerOrganization;
    }

    public void setAutomotiveDealerOrganization(AutomotiveDealerOrganization automotiveDealerOrganization) {
        this.automotiveDealerOrganization = automotiveDealerOrganization;
    }

   
    private AutomotiveDealerOrganization automotiveDealerOrganization;

    
    public AutomotiveDealerOrganization getAutomotiveDeaterOrganization() {
        return automotiveDealerOrganization;
    }

    public void setAutomotiveDeaterOrganization(AutomotiveDealerOrganization automotiveDealerOrganization) {
        this.automotiveDealerOrganization = automotiveDealerOrganization;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEngineCapacity() {
        return engineCapacity;
    }

    public void setEngineCapacity(String engineCapacity) {
        this.engineCapacity = engineCapacity;
    }

    public String getGearBoxType() {
        return gearBoxType;
    }

    public void setGearBoxType(String gearBoxType) {
        this.gearBoxType = gearBoxType;
    }

    public float getEfficiency() {
        return efficiency;
    }

    public void setEfficiency(float efficiency) {
        this.efficiency = efficiency;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public static int getCount() {
        return count;
    }

    public static void setCount(int count) {
        Automobile.count = count;
    }

   /* @Override
    public String toString() {
        return "id=" + id;
    }
*/
 

   
    
}
