/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Automobile;

import Business.Employee.Employee;
import java.util.ArrayList;

/**
 *
 * @author Vedant Singhvi
 */
public class AutomobileDirectory {
    
    private ArrayList<Automobile> automobileList;
  

    public AutomobileDirectory() {
        automobileList = new ArrayList<>();
    }

    public ArrayList<Automobile> getAutomobileList() {
        return automobileList;
    }

    public void setAutomobileList(ArrayList<Automobile> automobileList) {
        this.automobileList = automobileList;
    }

 
    
    public Automobile addAutomobile(){
        Automobile a = new Automobile();
        automobileList.add(a);
        return a;
    }

    
    public void removeAutomobile(Automobile a){
        automobileList.remove(a);
    }
    
    public Automobile searchAutomobile(String company){
        for (Automobile automobile : automobileList) {
            if(automobile.getCompanyName()==company){
                return automobile;
            }
        }
        return null;
    }
    
}
