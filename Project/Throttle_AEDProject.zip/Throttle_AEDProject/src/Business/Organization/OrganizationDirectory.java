/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Organization;

import java.util.ArrayList;

/**
 *
 * @author Vedant Singhvi
 */
public class OrganizationDirectory {
 
    
    private ArrayList<Organization> organizationList;

    public OrganizationDirectory() {
        organizationList = new ArrayList<>();
    }

    public ArrayList<Organization> getOrganizationList() {
        return organizationList;
    }
    
    public Organization createOrganization(Organization.Type type){
        Organization organization = null;
        if (type.getValue().equals(Organization.Type.AutomotiveDealerOrganization.getValue())){
            organization = new AutomotiveDealerOrganization();
            organizationList.add(organization);
        }
          else if (type.getValue().equals(Organization.Type.AutomotiveWorkShopOrganization.getValue())){
            organization = new AutomotiveWorkShopOrganization();
            organizationList.add(organization);
        }
           else if (type.getValue().equals(Organization.Type.CustomerOrganization.getValue())){
            organization = new CustomerOrganization();
            organizationList.add(organization);
        }
          else if (type.getValue().equals(Organization.Type.CityPollutionActionOrganization.getValue())){
            organization = new CityPollutionActionOrganization();
            organizationList.add(organization);
        }
           else if (type.getValue().equals(Organization.Type.CityPollutionMonitorOrganization.getValue())){
            organization = new CityPollutionMonitorOrganization();
            organizationList.add(organization);
    }
        return organization;
    }
    
    
}
