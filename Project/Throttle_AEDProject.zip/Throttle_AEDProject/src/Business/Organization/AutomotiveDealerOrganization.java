/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Organization;

import Business.Automobile.AutomobileDirectory;
import Business.Role.DealerRole;
import Business.Role.Role;
import java.util.ArrayList;

/**
 *
 * @author Vedant Singhvi
 */



public class AutomotiveDealerOrganization extends Organization {

    
    private AutomobileDirectory automobileDirectory;
    
        public AutomotiveDealerOrganization() {
        super(Organization.Type.AutomotiveDealerOrganization.getValue());
        automobileDirectory = new AutomobileDirectory();
    }

    public AutomobileDirectory getAutomobileDirectory() {
        return automobileDirectory;
    }

    public void setAutomobileDirectory(AutomobileDirectory automobileDirectory) {
        this.automobileDirectory = automobileDirectory;
    }

        
        
    @Override
    public ArrayList<Role> getSupportedRole() {
        ArrayList<Role> roles = new ArrayList<>();
        roles.add(new DealerRole());
        return roles;
    }
    
}
