/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Role;

import Business.Automobile.Automobile;
import Business.Automobile.AutomobileDirectory;
import Business.EcoSystem;
import Business.Enterprise.Enterprise;
import static Business.Enterprise.Enterprise.EnterpriseType.Automobile;
import Business.Network.Network;
import Business.Organization.AutomotiveDealerOrganization;
import Business.Organization.Organization;
import Business.UserAccount.UserAccount;
import javax.swing.JPanel;
import userInterface.AdministrativeRole.AdminWorkAreaJPanel;
import userInterface.AutomobileDealer.ManageAutomobileDealerWorkArea;

/**
 *
 * @author Vedant Singhvi
 */
public class DealerRole extends Role {

    @Override
    public JPanel createWorkArea(JPanel userProcessContainer, UserAccount account, Organization organization, Enterprise enterprise, EcoSystem system) {
        //Automobile automobile = new Automobile();
        //AutomobileDirectory automobileDirectory = new AutomobileDirectory();
                
        return new ManageAutomobileDealerWorkArea(userProcessContainer, enterprise, system, Enterprise.EnterpriseType.Automobile, (AutomotiveDealerOrganization)organization);
    }
}
