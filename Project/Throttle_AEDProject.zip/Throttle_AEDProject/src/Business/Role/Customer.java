/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Role;

import Business.BuyAutomobile.MasterOrderCatalog;
import Business.BuyAutomobile.Order;
import Business.EcoSystem;
import Business.Enterprise.Enterprise;
import Business.Network.Network;
import Business.Organization.AutomotiveDealerOrganization;
import Business.Organization.Organization;
import Business.UserAccount.UserAccount;
import javax.swing.JPanel;
import userInterface.Customer.ManageCustomerWorkArea;

/**
 *
 * @author Vedant Singhvi
 */
public class Customer extends Role{

    @Override
    public JPanel createWorkArea(JPanel userProcessContainer, UserAccount account, Organization organization, Enterprise enterprise, EcoSystem system) {
        return new ManageCustomerWorkArea (userProcessContainer, account, organization, enterprise, system);
    }
    
}